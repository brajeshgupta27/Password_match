# react-password-validation

## About

The following code is a custom react hook that is used to validate passwords.
Feel free to clone and use :) 

I love creating these easy to use code examples. If you could star my repo or give my medium article a clap it really helps me out.

## Includes the following password validtion:

- Minimum Character Validation
- Includes a number
- UpperCase
- LowerCase
- Includes Special Character
- Passwords Match

## Simple to get started

- Follow Me
- Clone Repo
- Npm install

### Resources

- Article/Guide
- https://medium.com/@steven_creates/creating-a-custom-react-hook-for-password-validation-46fc421c16ee

### Find Me

- LinkedIn: https://www.linkedin.com/in/steven-hofheins/
- Medium: https://medium.com/@steven_creates
- GitHub: https://github.com/StevenCreates

### If you end up cloning this more than once please star it
